﻿using CafeSaleManage.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace CafeSaleManage.Model
{

    public class BaseViewModel : INotifyPropertyChanged
    {
        public string roleview;
        private FeatureViewModel _selectedFeature;

        // ObservableCollection allows dynamic updates to UI
        public ObservableCollection<FeatureViewModel> Features { get; set; }

        // Tracks the currently selected feature
        public FeatureViewModel SelectedFeature
        {
            get => _selectedFeature;
            set
            {
                _selectedFeature = value;
                OnPropertyChanged();
            }
        }

        

        public RelayCommand SwitchFeatureCommand { get; private set; }
        // Constructor: Adds available features
        public BaseViewModel()
        {
            Features = new ObservableCollection<FeatureViewModel>
                {
                //new FeatureViewModel("Overview", new ViewModels.Overview_page()),
                new FeatureViewModel("Dashboard", new Model.Dashboard()),
                new FeatureViewModel("MODdash", new Model.DashboardMOD()),
                new FeatureViewModel("Employee", new Model.Employee()),
                new FeatureViewModel("Products", new Model.Products()),
                new FeatureViewModel("History", new Model.History()),
                new FeatureViewModel("Inventory", new Model.Inventory()),
                new FeatureViewModel("Report", new Model.Report()),
                new FeatureViewModel("PointOfSale", new Model.PointOfSale()),
                new FeatureViewModel("Pos", new Model.POS()),
            };

            SelectedFeature = Features[0]; // Default selection
            SwitchFeatureCommand = new RelayCommand(SwitchFeature);
        }


        private void SwitchFeature(object featureName)
        {
            var feature = Features.FirstOrDefault(f => f.Name == featureName as string);
            if (feature != null)
            {
                //SelectedFeature = feature;
                //OnPropertyChanged(nameof(SelectedFeature));
                SelectedFeature = feature;
            }
        }

        // Event for UI Binding Updates
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    // Feature ViewModel to store feature name and content
    public class FeatureViewModel
    {
        public string Name { get; set; }
        public UserControl Content { get; set; }

        public FeatureViewModel(string name, UserControl content)
        {
            Name = name;
            Content = content;
        }
    }
}
