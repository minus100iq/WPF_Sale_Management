﻿using CafeSaleManage.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CafeSaleManage
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            
            
            

            //baseModel.Show();
            //Close();
        }

      

        

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Are you sure you want to close current page?",
                                              "Exit Confirmation",
                                              MessageBoxButton.YesNo,
                                              MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        private void btn_max_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;  // Restore if already maximized
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void btn_min_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }



        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection("Server = localhost; Database = CAFEAPP; Integrated Security = True;");
            try
            {
                if (sqlCon.State == System.Data.ConnectionState.Closed)
                    sqlCon.Open();
                string query = "SELECT RTRIM(role) FROM LOGIN WHERE Username=@Username and Password=@Password";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.CommandType = System.Data.CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@Username", txtusername.Text);
                sqlCmd.Parameters.AddWithValue("@Password", txtpassword.Password);
                string role = (string)sqlCmd.ExecuteScalar();
                
                if (role == "admin" || role == "mod" || role == "sell")
                {

                    // Set the selected feature based on the role
                    
                    BaseModel baseModel = new BaseModel();
                    
                    if (role =="admin")
                    {
                        baseModel.admin();
                    } else if (role == "mod")
                    {
                        baseModel.mod();
                    } else {
                        baseModel.seller();
                    }
                    baseModel.Show();
                    Close();
                }
                else
                {
                    MessageBox.Show("Invalid username or Password");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void btn_register_Click(object sender, RoutedEventArgs e)
        {
            Registration registrationForm = new Registration();
            registrationForm.Show();
            Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
