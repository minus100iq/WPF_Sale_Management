﻿using CafeSaleManage.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CafeSaleManage
{
    /// <summary>
    /// Interaction logic for BaseModel.xaml
    /// </summary>
    public partial class BaseModel : Window
    {
        public BaseModel()
        {
            InitializeComponent();
        }

        public void admin()
        {
            rolename.Text = string.Empty;
            rolename.Text += "Administrator";
            admindash_btn.Visibility = Visibility.Visible;
            moddash_btn.Visibility = Visibility.Collapsed;
            employee_btn.Visibility = Visibility.Visible;
            product_btn.Visibility = Visibility.Visible;
            history_btn.Visibility = Visibility.Visible;
            inventory_btn.Visibility = Visibility.Visible;
            request_btn.Visibility = Visibility.Visible;
            sellerpos_btn.Visibility = Visibility.Visible;
            customerpos_btn.Visibility = Visibility.Visible;
        }   

        public void mod()
        {
            rolename.Text = string.Empty;
            rolename.Text += "Moderator";
            admindash_btn.Visibility = Visibility.Collapsed;
            moddash_btn.Visibility = Visibility.Visible;
            employee_btn.Visibility = Visibility.Collapsed;
            product_btn.Visibility = Visibility.Collapsed;
            history_btn.Visibility = Visibility.Visible;
            inventory_btn.Visibility = Visibility.Visible;
            request_btn.Visibility = Visibility.Visible;
            sellerpos_btn.Visibility = Visibility.Collapsed;
            customerpos_btn.Visibility = Visibility.Collapsed;

        }

        public void seller()
        {
            rolename.Text = string.Empty;
            rolename.Text += "Seller";
            admindash_btn.Visibility = Visibility.Collapsed;
            moddash_btn.Visibility = Visibility.Collapsed;
            employee_btn.Visibility = Visibility.Collapsed;
            product_btn.Visibility = Visibility.Collapsed;
            history_btn.Visibility = Visibility.Collapsed;
            inventory_btn.Visibility = Visibility.Collapsed;
            request_btn.Visibility = Visibility.Collapsed;
            sellerpos_btn.Visibility = Visibility.Visible;
            customerpos_btn.Visibility = Visibility.Visible;
        }

        private void btn_logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow frm = new MainWindow();
            frm.Show();
            Close();
        }
        private void btn_minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
        private void btn_maximize_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;  // Restore if already maximized
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }
        private void btn_close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
